package SayHello_02;

public interface Person {

    String getName();
    String sayHello();
}
