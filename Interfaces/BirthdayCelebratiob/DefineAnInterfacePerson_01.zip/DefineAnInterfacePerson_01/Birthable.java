package DefineAnInterfacePerson_01;

public interface Birthable {

    public String getBirthDate();

}
