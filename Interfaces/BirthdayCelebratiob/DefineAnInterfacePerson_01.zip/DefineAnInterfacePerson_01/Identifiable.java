package DefineAnInterfacePerson_01;

public interface Identifiable {

    public String getId();
}