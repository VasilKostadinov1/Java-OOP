package DefineAnInterfacePerson_01;

public interface Person {

    public String getName();
    public int getAge();


}
