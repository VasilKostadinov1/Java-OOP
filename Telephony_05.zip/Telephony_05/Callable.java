package Telephony_05;

public interface Callable {

    public String call();
}
