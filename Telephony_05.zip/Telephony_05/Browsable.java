package Telephony_05;

public interface Browsable {

    public String browse();

}
